--[[

     Neutron Awesome WM theme
     github.com/yoelbit

--]]

local gears = require("gears")
local lain  = require("lain")
local awful = require("awful")
local wibox = require("wibox")
local dpi   = require("beautiful.xresources").apply_dpi
local beautiful     = require("beautiful")

local os = os
local my_table = awful.util.table or gears.table -- 4.{0,1} compatibility

local theme                                     = {}
theme.dir                                       = os.getenv("HOME") .. "/.config/awesome/themes/Neutron"

theme.wallpaper                                 = theme.dir .. "/Wall.jpg"
theme.panel_top                                 = theme.dir .. "/panel/top_bar.png"
theme.panel_bottom                              = theme.dir .. "/panel/bottom_bar.png"
theme.panel_bg                                  = "transparent"
theme.transparent_bg	                        = "transparent"
theme.font                                      = "JetBrainsMono Nerd Font 10"
theme.titlebar_font                             = "JetBrainsMono Nerd Font 5"
theme.taglist_font                              = "Icons 16"
theme.taglist_bg_focus                          = "transparent"
theme.fg_normal                                 = "#7898fa"
theme.fg_focus                                  = "#666db0"
theme.fg_urgent                                 = "#7898fa"
theme.bg_normal                                 = "#000000"
theme.bg_focus                                  = "#000000"
theme.bg_urgent                                 = "#transparent"
theme.border_width                              = dpi(1)
theme.border_normal                             = "#3F3F3F"
theme.border_focus                              = "#3341bd"
theme.border_marked                             = "#3341bd"

theme.tasklist_bg_focus                         = "transparent"
theme.tasklist_bg_normal                        = "transparent"
theme.tasklist_font                             = "JetBrainsMono Nerd Font 9"

theme.net_bg                                    = "transparent" 
theme.date_bg                                   = "transparent"

--theme.titlebar_bg_focus                         = theme.bg_focus
theme.titlebar_bg_normal                        = "#000000"
--theme.titlebar_fg_focus                         = theme.fg_focus
theme.titlebar_full			        = theme.dir .. "/panel/full.png"

--Menú contextual boton derecho
theme.menu_height                               = dpi(16)
theme.menu_width                                = dpi(140)
theme.menu_submenu_icon                         = theme.dir .. "/icons/submenu.png"

--Marcas de selección de los espacios de trabajo
--theme.taglist_squares_sel                       = theme.dir .. "/icons/square_sel.png"
--theme.taglist_squares_unsel                     = theme.dir .. "/icons/square_unsel.png"

-- Icons Apps

theme.arch_btn                                  = theme.dir .. "/buttons/arch_btn.png"
theme.home_btn                                  = theme.dir .. "/buttons/home_btn.png"
theme.browser_btn                               = theme.dir .. "/buttons/browser_btn.png"
theme.gmail_btn                                 = theme.dir .. "/buttons/gmail_btn.png"
theme.facebook_btn                              = theme.dir .. "/buttons/facebook_btn.png"              
theme.twich_btn                                 = theme.dir .. "/buttons/twich_btn.png" 
theme.discord_btn                               = theme.dir .. "/buttons/discord_btn.png" 
theme.what_btn                                  = theme.dir .. "/buttons/what_btn.png" 
theme.youtube_btn                               = theme.dir .. "/buttons/youtube_btn.png"
theme.backups_btn                               = theme.dir .. "/buttons/backups_btn.png"         
theme.tuit_btn                                  = theme.dir .. "/buttons/tuit_btn.png"         
theme.git_btn                                   = theme.dir .. "/buttons/git_btn.png"         
theme.libre_btn                                 = theme.dir .. "/buttons/libre_btn.png"          
theme.pdf_btn                                   = theme.dir .. "/buttons/pdf_btn.png"        
theme.images_btn                                = theme.dir .. "/buttons/images_btn.png"           
theme.term_btn                                  = theme.dir .. "/buttons/term_btn.png"       
theme.vlc_btn                                   = theme.dir .. "/buttons/vlc_btn.png"        
theme.nord_btn                                  = theme.dir .. "/buttons/nord_btn.png"       
theme.lock_btn                                  = theme.dir .. "/buttons/lock_btn.png"        
theme.dots_btn                                  = theme.dir .. "/buttons/dots_btn.png"       
theme.pics_btn                                  = theme.dir .. "/buttons/pics_btn.png"      
theme.drive_btn                                 = theme.dir .. "/buttons/drive_btn.png"       
theme.music_btn                                 = theme.dir .. "/buttons/music_btn.png"        
theme.filemanager_btn                           = theme.dir .. "/buttons/filemanager_btn.png"     
theme.recycle_btn                               = theme.dir .. "/buttons/recycle_btn.png"       
theme.notify_btn                                = theme.dir .. "/buttons/notify_btn.png"  
theme.keyboardlayout_btn                        = theme.dir .. "/buttons/keyboardlayout_btn.png" 
theme.connectwifi_btn                           = theme.dir .. "/buttons/connectwifi_btn.png"

theme.layout_tile                               = theme.dir .. "/icons/tile.png"
theme.layout_tileleft                           = theme.dir .. "/icons/tileleft.png"
theme.layout_tilebottom                         = theme.dir .. "/icons/tilebottom.png"
theme.layout_tiletop                            = theme.dir .. "/icons/tiletop.png"
theme.layout_fairv                              = theme.dir .. "/icons/fairv.png"
theme.layout_fairh                              = theme.dir .. "/icons/fairh.png"
theme.layout_spiral                             = theme.dir .. "/icons/spiral.png"
theme.layout_dwindle                            = theme.dir .. "/icons/dwindle.png"
theme.layout_max                                = theme.dir .. "/icons/max.png"
theme.layout_fullscreen                         = theme.dir .. "/icons/fullscreen.png"
theme.layout_magnifier                          = theme.dir .. "/icons/magnifier.png"
theme.layout_floating                           = theme.dir .. "/icons/floating.png"

theme.layout_termfair                           = theme.dir .. "/icons/termfair.png"
theme.layout_centerfair                         = theme.dir .. "/icons/centerfair.png"
theme.layout_centerwork                         = theme.dir .. "/icons/centerwork.png"
theme.layout_centerworkh                        = theme.dir .. "/icons/centerworkh.png"


theme.widget_ac                                 = theme.dir .. "/icons/battery.png"
theme.widget_battery                            = theme.dir .. "/icons/battery.png"
theme.widget_battery_low                        = theme.dir .. "/icons/battery_low.png"
theme.widget_battery_empty                      = theme.dir .. "/icons/battery_empty.png"
theme.widget_mem                                = theme.dir .. "/icons/mem.png"
theme.widget_cpu                                = theme.dir .. "/icons/cpu.png"
theme.widget_temp                               = theme.dir .. "/icons/temp.png"
theme.widget_net                                = theme.dir .. "/icons/net.png"
theme.widget_hdd                                = theme.dir .. "/icons/hdd.png"
theme.widget_music                              = theme.dir .. "/icons/note.png"
theme.widget_music_on                           = theme.dir .. "/icons/note_on.png"
theme.widget_vol                                = theme.dir .. "/icons/vol.png"
theme.widget_vol_low                            = theme.dir .. "/icons/vol_low.png"
theme.widget_vol_no                             = theme.dir .. "/icons/vol_no.png"
theme.widget_vol_mute                           = theme.dir .. "/icons/vol_mute.png"
theme.widget_mail                               = theme.dir .. "/icons/mail.png"
theme.widget_mail_on                            = theme.dir .. "/icons/mail_on.png"
theme.widget_cal                                = theme.dir .. "/icons/calendar.png"

theme.tasklist_plain_task_name                  = true
theme.tasklist_disable_icon                     = true

-- Espacio entre ventanas en mosaico
theme.useless_gap                               = dpi(2)

theme.titlebar_close_button_focus               = theme.dir .. "/icons/titlebar/close_focus.png"
theme.titlebar_close_button_normal              = theme.dir .. "/icons/titlebar/close_normal.png"
theme.titlebar_ontop_button_focus_active        = theme.dir .. "/icons/titlebar/ontop_focus_active.png"
theme.titlebar_ontop_button_normal_active       = theme.dir .. "/icons/titlebar/ontop_normal_active.png"
theme.titlebar_ontop_button_focus_inactive      = theme.dir .. "/icons/titlebar/ontop_focus_inactive.png"
theme.titlebar_ontop_button_normal_inactive     = theme.dir .. "/icons/titlebar/ontop_normal_inactive.png"
theme.titlebar_sticky_button_focus_active       = theme.dir .. "/icons/titlebar/sticky_focus_active.png"
theme.titlebar_sticky_button_normal_active      = theme.dir .. "/icons/titlebar/sticky_normal_active.png"
theme.titlebar_sticky_button_focus_inactive     = theme.dir .. "/icons/titlebar/sticky_focus_inactive.png"
theme.titlebar_sticky_button_normal_inactive    = theme.dir .. "/icons/titlebar/sticky_normal_inactive.png"
theme.titlebar_floating_button_focus_active     = theme.dir .. "/icons/titlebar/floating_focus_active.png"
theme.titlebar_floating_button_normal_active    = theme.dir .. "/icons/titlebar/floating_normal_active.png"
theme.titlebar_floating_button_focus_inactive   = theme.dir .. "/icons/titlebar/floating_focus_inactive.png"
theme.titlebar_floating_button_normal_inactive  = theme.dir .. "/icons/titlebar/floating_normal_inactive.png"
theme.titlebar_maximized_button_focus_active    = theme.dir .. "/icons/titlebar/maximized_focus_active.png"
theme.titlebar_maximized_button_normal_active   = theme.dir .. "/icons/titlebar/maximized_normal_active.png"
theme.titlebar_maximized_button_focus_inactive  = theme.dir .. "/icons/titlebar/maximized_focus_inactive.png"
theme.titlebar_maximized_button_normal_inactive = theme.dir .. "/icons/titlebar/maximized_normal_inactive.png"
theme.titlebar_minimize_button_focus            = theme.dir .. "/icons/titlebar/sticky_focus_active.png"
theme.titlebar_minimize_button_normal           = theme.dir .. "/icons/titlebar/sticky_normal_active.png"


awful.util.tagnames   = { " ", " ", " ", " ", " " }

local markup = lain.util.markup
local separators = lain.util.separators

-- Textclock
local clockicon = wibox.widget.imagebox(theme.widget_clock)
local clock = awful.widget.watch(
    "date +'%a %d %b %R'", 60,
    function(widget, stdout)
        widget:set_markup(" " .. markup.font(theme.font, stdout, markup("#666db0")))
    end
)

-- Calendar
theme.cal = lain.widget.cal({
    attach_to = { clock },
    notification_preset = {
        font = "Terminus 10",
        fg   = theme.fg_focus,
        bg   = theme.bg_normal,
    }
})



-- Arch JgMenu launch

local arch_btn = wibox.widget.imagebox(theme.arch_btn)
arch_btn:buttons(my_table.join(awful.button({ }, 1, function () 
    awful.util.spawn_with_shell("/home/yoel/.config/scripts/jgmenu.sh") 
    end)))

-- Home
local home_btn = wibox.widget.imagebox(theme.home_btn)
home_btn:buttons(my_table.join(awful.button({ }, 1, function () 
    awful.util.spawn_with_shell("caja") 
    end)))    
    
-- Browser
local browser_btn = wibox.widget.imagebox(theme.browser_btn)
browser_btn:buttons(my_table.join(awful.button({ }, 1, function () 
    awful.util.spawn_with_shell("firefox") 
    end)))  

-- Gmail
local gmail_btn = wibox.widget.imagebox(theme.gmail_btn)
gmail_btn:buttons(my_table.join(awful.button({ }, 1, function () 
    awful.util.spawn_with_shell("firefox -url https://mail.google.com/mail/u/0/#inbox") 
    end)))  

-- Facebook
local facebook_btn = wibox.widget.imagebox(theme.facebook_btn)
facebook_btn:buttons(my_table.join(awful.button({ }, 1, function () 
    awful.util.spawn_with_shell("firefox -url https://www.google.es") 
    end))) 
    
-- Twich
local twich_btn = wibox.widget.imagebox(theme.twich_btn)
twich_btn:buttons(my_table.join(awful.button({ }, 1, function () 
    awful.util.spawn_with_shell("firefox -url https://www.google.es") 
    end))) 
    
-- Discord
local discord_btn = wibox.widget.imagebox(theme.discord_btn)
discord_btn:buttons(my_table.join(awful.button({ }, 1, function () 
    awful.util.spawn_with_shell("firefox -url https://www.google.es") 
    end))) 
    
-- What
local what_btn = wibox.widget.imagebox(theme.what_btn)
what_btn:buttons(my_table.join(awful.button({ }, 1, function () 
    awful.util.spawn_with_shell("firefox -url https://www.google.es") 
    end)))     
    
-- Youtube
local youtube_btn = wibox.widget.imagebox(theme.youtube_btn)
youtube_btn:buttons(my_table.join(awful.button({ }, 1, function () 
    awful.util.spawn_with_shell("firefox -url https:/www.youtube.com") 
    end)))  

-- Backups
local backups_btn = wibox.widget.imagebox(theme.backups_btn)
backups_btn:buttons(my_table.join(awful.button({ }, 1, function () 
    awful.util.spawn_with_shell("firefox -url https://www.google.es") 
    end)))  

-- Tuit
local tuit_btn = wibox.widget.imagebox(theme.tuit_btn)
tuit_btn:buttons(my_table.join(awful.button({ }, 1, function () 
    awful.util.spawn_with_shell("firefox -url https://www.google.es") 
    end)))  

-- Git
local git_btn = wibox.widget.imagebox(theme.git_btn)
git_btn:buttons(my_table.join(awful.button({ }, 1, function () 
    awful.util.spawn_with_shell("firefox -url https://www.google.es") 
    end))) 

-- Libre
local libre_btn = wibox.widget.imagebox(theme.libre_btn)
libre_btn:buttons(my_table.join(awful.button({ }, 1, function () 
    awful.util.spawn_with_shell("firefox -url https://www.google.es") 
    end))) 

-- Pdf
local pdf_btn = wibox.widget.imagebox(theme.pdf_btn)
pdf_btn:buttons(my_table.join(awful.button({ }, 1, function () 
    awful.util.spawn_with_shell("firefox -url https://www.google.es") 
    end))) 
    
-- Images
local images_btn = wibox.widget.imagebox(theme.images_btn)
images_btn:buttons(my_table.join(awful.button({ }, 1, function () 
    awful.util.spawn_with_shell("firefox -url https://www.google.es") 
    end)))  

-- Term
local term_btn = wibox.widget.imagebox(theme.term_btn)
term_btn:buttons(my_table.join(awful.button({ }, 1, function () 
    awful.util.spawn_with_shell("firefox -url https://www.google.es") 
    end)))      

-- Vlc
local vlc_btn = wibox.widget.imagebox(theme.vlc_btn)
vlc_btn:buttons(my_table.join(awful.button({ }, 1, function () 
    awful.util.spawn_with_shell("firefox -url https://www.google.es") 
    end)))     
    
-- Nord
local nord_btn = wibox.widget.imagebox(theme.nord_btn)
nord_btn:buttons(my_table.join(awful.button({ }, 1, function () 
    awful.util.spawn_with_shell("firefox -url https://www.google.es") 
    end)))
    
-- Lock
local lock_btn = wibox.widget.imagebox(theme.lock_btn)
lock_btn:buttons(my_table.join(awful.button({ }, 1, function () 
    awful.util.spawn_with_shell("firefox -url https://www.google.es") 
    end)))       

-- Dots
local dots_btn = wibox.widget.imagebox(theme.dots_btn)
dots_btn:buttons(my_table.join(awful.button({ }, 1, function () 
    awful.util.spawn_with_shell("firefox -url https://www.google.es") 
    end))) 

-- Pics
local pics_btn = wibox.widget.imagebox(theme.pics_btn)
pics_btn:buttons(my_table.join(awful.button({ }, 1, function () 
    awful.util.spawn_with_shell("firefox -url https://www.google.es") 
    end))) 
    
-- Drive
local drive_btn = wibox.widget.imagebox(theme.drive_btn)
drive_btn:buttons(my_table.join(awful.button({ }, 1, function () 
    awful.util.spawn_with_shell("firefox -url https://www.google.es") 
    end))) 
    
-- Music
local music_btn = wibox.widget.imagebox(theme.music_btn)
music_btn:buttons(my_table.join(awful.button({ }, 1, function () 
    awful.util.spawn_with_shell("firefox -url https://www.google.es") 
    end)))     
    
-- Filemanager
local filemanager_btn = wibox.widget.imagebox(theme.filemanager_btn)
filemanager_btn:buttons(my_table.join(awful.button({ }, 1, function () 
    awful.util.spawn_with_shell("firefox -url https://www.google.es") 
    end)))       

-- Recycle
local recycle_btn = wibox.widget.imagebox(theme.recycle_btn)
recycle_btn:buttons(my_table.join(awful.button({ }, 1, function () 
    awful.util.spawn_with_shell("firefox -url https://www.google.es") 
    end)))    

-- Archupdates
local archupdates = awful.widget.watch('bash -c "checkupdates | wc -l"', 20, function(widget, stdout) 
    widget:set_markup(markup.fontfg(theme.font, "#7898fa", "    Updates: " .. string.format("%4s", stdout) .. " "))
end)

-- Temp

local systemp = awful.widget.watch('bash -c "sensors -A | grep temp1 | cut -c14-22"', 15, function(widget, stdout)
    widget:set_markup(markup.fontfg(theme.font, "#7898fa", " " .. stdout .. " "))
end)

-- Temp High

local systemp_high = awful.widget.watch('bash -c "sensors -A | grep temp1 | cut -c32-40"', 15, function(widget, stdout)
   widget:set_markup(markup.fontfg(theme.font, "#7898fa", " " .. stdout .. " "))
end)

-- Uptime
local uptime = awful.widget.watch('bash -c "uptime | grep up | cut -c14-18"', 15, function(widget, stdout)
    widget:set_markup(markup.fontfg(theme.font, "#7898fa", "  Time: " .. string.format("%8s", stdout) .. " "))
end)

-- Kernel Info
local kernelinfo = awful.widget.watch('bash -c "uname -r | grep 1 | cut -c1-13"', 15, function(widget, stdout)
    widget:set_markup(markup.fontfg(theme.font, "#7898fa", "  " .. stdout .. " "))
end)

-- Notify

local notify_btn = wibox.widget.imagebox(theme.notify_btn)
notify_btn:buttons(my_table.join(awful.button({ }, 1, function () 
    awful.util.spawn_with_shell("firefox -url https://www.google.es") 
    end))) 

-- Keyboad
local keyboardlayout_btn = wibox.widget.imagebox(theme.keyboardlayout_btn)
    keyboardlayout_btn:buttons(my_table.join(awful.button({ }, 1, function () 
    awful.util.spawn_with_shell("firefox -url https://www.google.es") 
    end)))
    
-- Connect Wifi
local connectwifi_btn = wibox.widget.imagebox(theme.connectwifi_btn)
    connectwifi_btn:buttons(my_table.join(awful.button({ }, 1, function () 
    awful.util.spawn_with_shell("nm-connection-editor") 
    end)))  

-- MEM
local memicon = wibox.widget.imagebox(theme.widget_mem)
local mem = lain.widget.mem({
    settings = function()
        widget:set_markup(markup.font(theme.font, " " .. string.format("%4s", mem_now.used) .. "MB "))
    end
})

-- CPU
local cpuicon = wibox.widget.imagebox(theme.widget_cpu)
local cpu = lain.widget.cpu({
    settings = function()
        widget:set_markup(markup.font(theme.font, " " .. string.format("%5s", cpu_now.usage) .. "% "))   
    end
})


-- Coretemp
local tempicon = wibox.widget.imagebox(theme.widget_temp)
local temp = lain.widget.temp({
    settings = function()
        widget:set_markup(markup.font(theme.font, " " .. coretemp_now .. "°C "))
    end
})

-- / fs
local fsicon = wibox.widget.imagebox(theme.widget_hdd)

-- commented because it needs Gio/Glib >= 2.54
theme.fs = lain.widget.fs({
    notification_preset = { fg = theme.fg_normal, bg = theme.bg_normal, font = "Terminus 10" },
    settings = function()
        widget:set_markup(markup.font(theme.font, "SDD " .. fs_now["/"].percentage .. "% "))
    end
})
--]]


-- Battery
local baticon = wibox.widget.imagebox(theme.widget_battery)
local bat = lain.widget.bat({
    settings = function()
        if bat_now.status and bat_now.status ~= "N/A" then
            if bat_now.ac_status == 1 then
                baticon:set_image(theme.widget_ac)
            elseif not bat_now.perc and tonumber(bat_now.perc) <= 5 then
                baticon:set_image(theme.widget_battery_empty)
            elseif not bat_now.perc and tonumber(bat_now.perc) <= 15 then
                baticon:set_image(theme.widget_battery_low)
            else
                baticon:set_image(theme.widget_battery)
            end
            widget:set_markup(markup.font(theme.font, " " .. bat_now.perc .. "% "))
        else
            widget:set_markup(markup.font(theme.font, " AC "))
            baticon:set_image(theme.widget_ac)
        end
    end
})

-- ALSA volume
local volicon = wibox.widget.imagebox(theme.widget_vol)
theme.volume = lain.widget.alsa({
    settings = function()
        if volume_now.status == "off" then
            volicon:set_image(theme.widget_vol_mute)
        elseif tonumber(volume_now.level) == 0 then
            volicon:set_image(theme.widget_vol_no)
        elseif tonumber(volume_now.level) <= 50 then
            volicon:set_image(theme.widget_vol_low)
        else
            volicon:set_image(theme.widget_vol)
        end

        widget:set_markup(markup.font(theme.font, " " .. string.format("%3s", volume_now.level) .. "% "))
    end 
})
theme.volume.widget:buttons(awful.util.table.join(
                               awful.button({}, 1, function ()
                                     awful.util.spawn("pavucontrol")
                                     theme.volume.update()
                               end),
                               awful.button({}, 4, function ()
                                     awful.util.spawn("amixer set Master 1%+")
                                     theme.volume.update()
                               end),
                               awful.button({}, 5, function ()
                                     awful.util.spawn("amixer set Master 1%-")
                                     theme.volume.update()
                               end)
))

-- Net
local neticon = wibox.widget.imagebox(theme.widget_net)
local net = lain.widget.net({
    settings = function()
        widget:set_markup(markup.font(theme.font,
                          markup("#7898fa", "RC " .. string.format("%06.1f", net_now.received))
                          .. " " ..
                          markup("#7898fa", "SE " .. string.format("%06.1f", net_now.sent) .. " ")))
    end
})

local calicon = wibox.widget.imagebox(theme.widget_cal)

-- Separators
local spr     = wibox.widget.textbox(' ')
local spr_max = wibox.widget.textbox('      ')


function theme.at_screen_connect(s)
    
    -- Quake application
    s.quake = lain.util.quake({ app = awful.util.terminal })

    --[[ If wallpaper is a function, call it with the screen
    local wallpaper = theme.wallpaper
    if type(wallpaper) == "function" then
        wallpaper = wallpaper(s)
    end
    gears.wallpaper.maximized(wallpaper, s, true)--]]

    -- Tags
    awful.tag(awful.util.tagnames, s, awful.layout.layouts)

    -- Create a promptbox for each screen
    s.mypromptbox = awful.widget.prompt()
    
    -- Create an imagebox widget which will contains an icon indicating which layout we're using.
    -- We need one layoutbox per screen.  
    s.mylayoutbox = awful.widget.layoutbox(s)
    s.mylayoutbox:buttons(my_table.join(
                           awful.button({}, 1, function () awful.layout.inc( 1) end),
                           awful.button({}, 2, function () awful.layout.set( awful.layout.layouts[1] ) end),
                           awful.button({}, 3, function () awful.layout.inc(-1) end),
                           awful.button({}, 4, function () awful.layout.inc( 1) end),
                           awful.button({}, 5, function () awful.layout.inc(-1) end)))
   
    -- Create a taglist widget
    s.mytaglist = awful.widget.taglist(s, awful.widget.taglist.filter.all, awful.util.taglist_buttons)

    -- Create a tasklist widget
    s.mytasklist = awful.widget.tasklist(s, awful.widget.tasklist.filter.currenttags, awful.util.tasklist_buttons)
    
     -- Create the wibox Top Bar
    s.wibox_top_bar = awful.wibar({ position = "top", screen = s, height = dpi(35), bgimage = theme.panel_top, fg = theme.fg_normal, bg = theme.panel_bg })
    
    -- Add widgets to the wibox Top Bar
    s.wibox_top_bar:setup {  
         
         layout = wibox.layout.align.horizontal,
         {     -- Mernu Arch 
               layout = wibox.container.margin(nil,43,0,8,8),
               arch_btn,      
         },
        
         {    -- Apps Buttons & widgets Top Bar 
              layout = wibox.layout.fixed.horizontal,    
                                      
                  {     -- Home
                        layout = wibox.container.margin(nil,84,0,8,8),
                        home_btn,
                  },
                  {     -- Browser
                        layout = wibox.container.margin(nil,4,0,7,7),
                        browser_btn,  
                  },
                  {     -- Gmail
                        layout = wibox.container.margin(nil,4,0,8,6),
                        gmail_btn,
                  },
                  {     -- Facebook
                        layout = wibox.container.margin(nil,5,0,9,7),
                        facebook_btn,      
                  },
                  {     -- Twich
                        layout = wibox.container.margin(nil,5,0,10,8),
                        twich_btn,
                  },
                  {     -- Discord
                        layout = wibox.container.margin(nil,5,0,8,6),
                        discord_btn,    
                  },
                  {     -- What
                        layout = wibox.container.margin(nil,5,0,8,7),
                        what_btn,
                  },
                  {     -- Youtube
                        layout = wibox.container.margin(nil,3,0,6,4),
                        youtube_btn,      
                  },
                  {     -- Backups
                        layout = wibox.container.margin(nil,5,0,9,8),
                        backups_btn,      
                  },
                  {     -- Tuit
                        layout = wibox.container.margin(nil,4,0,7,6),
                        tuit_btn,      
                  },
                  {     -- Git
                        layout = wibox.container.margin(nil,2,0,8,8),
                        git_btn,      
                  },
                  {     -- Libre
                        layout = wibox.container.margin(nil,5,0,10,9),
                        libre_btn,      
                  },
                  {     -- Pdf
                        layout = wibox.container.margin(nil,7,0,10,9),
                        pdf_btn,      
                  },
                  {     -- Images
                        layout = wibox.container.margin(nil,6,0,7,5),
                        images_btn,      
                  },
                  {     -- Term
                        layout = wibox.container.margin(nil,5,0,7,5),
                        term_btn,      
                  },
                  {     -- Vlc
                        layout = wibox.container.margin(nil,4,0,7,6),
                        vlc_btn,      
                  },
                  {     -- NordVpn
                        layout = wibox.container.margin(nil,5,0,10,8),
                        nord_btn, 
                  },
                  {     -- Lock
                        layout = wibox.container.margin(nil,6,0,9,10),
                        lock_btn,
                  },
                  {     -- DotsFiles
                        layout = wibox.container.margin(nil,6,0,6,7),
                        dots_btn,      
                  },
                  {     -- Pics
                        layout = wibox.container.margin(nil,3,0,5,6),
                        pics_btn,      
                  },
                  {     -- Drive
                        layout = wibox.container.margin(nil,2,0,4,5),
                        drive_btn,      
                  },
                  {     -- Music
                        layout = wibox.container.margin(nil,4,0,8,9),
                        music_btn,      
                  }, 
                  {     -- File Manager
                        layout = wibox.container.margin(nil,5,0,8,7),
                        filemanager_btn,      
                  },
                  {     -- Recycle
                        layout = wibox.container.margin(nil,5,0,9,9),
                        recycle_btn,      
                  },
                  {     -- Kernel Info
                        layout = wibox.container.margin(nil,80,0,11,12),
                        wibox.container.background(kernelinfo, theme.transparent_bg),                     
                  },  
                  {     -- Uptime
                        layout = wibox.container.margin(nil,84,0,9,10),
                        wibox.container.background(uptime, theme.transparent_bg),                     
                  },     
                  {     -- Arch Updates
                        layout = wibox.container.margin(nil,70,0,9,10),
                        wibox.container.background(archupdates, theme.transparent_bg),                     
                  },
                  {     -- Temp
                        layout = wibox.container.margin(nil,100,0,9,10),
                        wibox.container.background(systemp, theme.transparent_bg),                     
                  },
                  {     -- Temp High
                        layout = wibox.container.margin(nil,10,0,9,10),
                        wibox.container.background(systemp_high, theme.transparent_bg),                     
                  },
                  {     -- Notify
                        layout = wibox.container.margin(nil,93,0,9,10),
                        wibox.container.background(notify_btn, theme.transparent_bg),                     
                  },
                  {     -- Keyboard
                        layout = wibox.container.margin(nil,10,0,5,6),
                        wibox.container.background(keyboardlayout_btn, theme.transparent_bg),                     
                  },
                  {     -- Volume Icon
                        layout = wibox.container.margin(nil,10,0,10,11),
                        wibox.container.background(volicon, theme.transparent_bg),                     
                  },
                  {     -- Volume Widget
                        layout = wibox.container.margin(nil,-5,0,5,6),
                        wibox.container.background(theme.volume.widget, theme.transparent_bg),                     
                  },
                  {     -- Connect Wifi 
                        layout = wibox.container.margin(nil,2,0,10,11),
                        wibox.container.background(connectwifi_btn, theme.transparent_bg),                     
                  },
                  {     -- Layoutbox
                        layout = wibox.container.margin(nil,10,0,9,11),
                        wibox.container.background(s.mylayoutbox, theme.transparent_bg),                
                  },
    
         },   
    }
    
    -- Create the wibox Bottom Bar
    s.wibox_bottom_bar = awful.wibar({ position = "bottom", screen = s, height = dpi(35), bgimage = theme.panel_bottom, fg = theme.fg_normal, bg = theme.panel_bg })
    
    -- Add widgets to the wibox Bottom Bar
    s.wibox_bottom_bar:setup {   
    
        layout = wibox.layout.align.horizontal,   
        {    -- Workspaces widget     
             layout = wibox.container.margin(nil,38,18,5,5),        
             s.mytaglist,                                
        },        
        {    -- Tasklist widget
             layout = wibox.container.margin(nil,49,25,5,7),
             s.mytasklist,
        },      
        {    -- Widgets  
             layout = wibox.layout.fixed.horizontal,
                 {    -- Widget FS
            	      layout = wibox.container.margin(nil,50,0,12,12),
                      wibox.container.background(fsicon, theme.transparent_bg),
                 },
                 {
            	      layout = wibox.container.margin(nil,8,22,4,6),
                      wibox.container.background(theme.fs.widget, theme.transparent_bg),
               	 },          
                 {    -- Widget Mem
            	      layout = wibox.container.margin(nil,47,0,12,12),
                      wibox.container.background(memicon, theme.transparent_bg),
               	 },
                 {
            	      layout = wibox.container.margin(nil,0,20,4,6),
                      wibox.container.background(mem.widget, theme.transparent_bg),
                 },
                 {    -- Widget CPU2
            	      layout = wibox.container.margin(nil,45,0,8,9),
                      wibox.container.background(cpuicon, theme.transparent_bg),
               	 },
                 {
            	      layout = wibox.container.margin(nil,0,27,4,6),
                      wibox.container.background(cpu.widget, theme.transparent_bg),
               	 },              
                 {    -- Widget CPU1
            	      layout = wibox.container.margin(nil,40,0,8,9),
                      wibox.container.background(cpuicon, theme.transparent_bg),
               	 },
                 {
            	      layout = wibox.container.margin(nil,0,27,4,6),
                      wibox.container.background(cpu.widget, theme.transparent_bg),
               	 },              
                 {    -- Widget Batery & AC
            	      layout = wibox.container.margin(nil,50,0,13,14),
                      baticon, 
               	 },
                 {
            	      layout = wibox.container.margin(nil,5,48,4,6),
                      bat.widget,
               	 },     
                 {    -- Widget Net 
            	      layout = wibox.container.margin(nil,31,5,9,11),
                      wibox.container.background(neticon, theme.net_bg),
               	 },
                 {
            	      layout = wibox.container.margin(nil,5,87,4,6),
                      wibox.container.background(net.widget, theme.net_bg),
               	 },       
                 {    -- Widget Clock & Calendar 
            	      layout = wibox.container.margin(nil,0,0,9,12),
                      wibox.container.background(calicon, theme.widget_cal), 
               	 },
            	 {
            	      layout = wibox.container.margin(nil,9,48,0,4),
                      clock,
               	 },
         },    
     }         
        
end

-------------TOP TITLEBAR ----------------

-- Add a titlebar if titlebars_enabled is set to true in the rules.

local my_imagebox = wibox.widget.imagebox(theme.titlebar_full, false),

client.connect_signal("request::titlebars", function(c)
    -- buttons for the titlebar      
local top_titlebar = awful.titlebar(c, {

    
   size      = 16,
   bg_normal = "transparent",
   bg_focus  = "transparent",
                    
   fg_normal = "#7898fa",
   fg_focus  = "#7898fa",
  
    -- resize_allowed = true,
    -- bgimage = theme.titlebar_line,
    -- position = 'left',
   	            
    
})

-- buttons for the titlebar
local buttons = gears.table.join(
    awful.button({ }, 1, function()
        client.focus = c
        c:raise()
        awful.mouse.client.move(c)
    end),
    awful.button({ }, 3, function()
        client.focus = c
        c:raise()
        awful.mouse.client.resize(c)

    end)
)

local w = awful.titlebar.widget.titlewidget(c),



top_titlebar : setup {

layout = wibox.layout.align.horizontal,

    { -- Left
      
      layout  = wibox.layout.fixed.horizontal,
      
         {
              layout = wibox.container.margin(nil,0,0,7,0),
           
                   wibox.widget {
                       {
                            left   = 0,
                            top    = 0,
                            bottom = 0,
                            right  = 40,
                           
                            widget = wibox.container.margin,
                            
                       },
                            bg         = "#7898fa",      
                            shape      = function(cr, width, height)
		                       gears.shape.rectangle(cr, 60, 16)
		                       cr:stroke()       
	                               end,
                    
                            widget     = wibox.container.background,
                       }
                
         },
 
         {
              layout = wibox.container.margin(nil,-5,0,0,0),

         },

  
    },

    
    { -- Middle

    layout  = wibox.layout.fixed.horizontal, -- Titlewidget
    {
              layout = wibox.container.margin(nil,0,0,0,0),
 

                   wibox.widget {
                 


                       {

                            left   = 15,
                            top    = 0,
                            bottom = 0,
                            right  = 15,
                            forced_width  = 400,
    
                            widget = wibox.container.margin,


                            {
                           
                                align = "left",
                                widget = awful.titlebar.widget.titlewidget(c), 
                                
                            },
                             

                       },
                    
                    widget  = wibox.container.background,
                    
                       bg      = "#000000",  
                       fg = "#7898fa",
                       
                       shape   = function(cr, w, height)                     
		                
		               gears.shape.hexagon(cr, w, 16)	                       
		               cr:stroke()  
                             --cr:fill()
	                       end,

                       },
                       


     
         },
         
    
         

         {
        
              layout = wibox.container.margin(nil,-5,0,0,8),

                   wibox.widget {

                       {

                            left   = 15,
                            top    = 0,
                            bottom = 0,
                            right  = 15,
                            forced_width  = 621,
                            widget = wibox.container.margin,
 
                       },
                           
                       bg      = "#ff0000",         
                       shape   = function(cr, w, height)
                                                             
                               gears.shape.radial_progress(cr,w*6, 8, .1)                                    
		               cr:stroke() 
	                       end,
	               widget     = wibox.container.background,        

                       }
     
         },
         {
        
              layout = wibox.container.margin(nil,-5,0,0,8),

                   wibox.widget {

                       {

                            left   = 15,
                            top    = 0,
                            bottom = 0,
                            right  = 15,
                            forced_width  = 5000,
                            widget = wibox.container.margin,
     
                       },
                           
                       bg      = "#ff0000",         
                       shape   = function(cr, w, height)
                                                             
                               gears.shape.radial_progress(cr,5000, 8, .1) 

		               cr:stroke() 
	                       end,
	               widget     = wibox.container.background,        

                       }
     
         },
         
    },

    
    { -- Right

         layout = wibox.layout.fixed.horizontal,   

         {
              layout = wibox.container.margin(nil,0,0,0,0),

         },
          
         {
              layout = wibox.container.margin(nil,0,-120,0,0),
           
                   wibox.widget {
                       {
                            left   = 0,
                            top    = 0,
                            bottom = 0,
                            right  = 0,
                      
                            widget = wibox.container.margin,
                       },
                            bg         = "#ff0000",         
                            shape      = function(cr, width, height)
		                       gears.shape.hexagon(cr, 120, 16)
		                       cr:stroke()       
	                               end,
                    
                            widget     = wibox.container.background,
                       }
                
         },
         
         {
              layout = wibox.container.margin(nil,12,0,0),
              wibox.container.background(awful.titlebar.widget.floatingbutton (c)), 

         },
         {
              layout = wibox.container.margin(nil,0,0,0,0),
              wibox.container.background(awful.titlebar.widget.maximizedbutton(c)), 
            
         },
         {
              layout = wibox.container.margin(nil,0,0,0,0),
              wibox.container.background(awful.titlebar.widget.minimizebutton(c)), 
            
         },
         {
              layout = wibox.container.margin(nil,0,0,0,0),
              wibox.container.background(awful.titlebar.widget.stickybutton(c)), 
            
         },
         {
              layout = wibox.container.margin(nil,0,0,0,0),
              wibox.container.background(awful.titlebar.widget.ontopbutton(c)), 
            
         },
         {
              layout = wibox.container.margin(nil,0,7,0,0),
              wibox.container.background(awful.titlebar.widget.closebutton(c)), 
            
         },
         
         {
              layout = wibox.container.margin(nil,4,0,7,0),
           
                   wibox.widget {
                       {
                            left   = 40,
                            top    = 0,
                            bottom = 0,
                            right  = 0,

                            widget = wibox.container.margin,
                       },
                            bg         = "#ff0000",         
                            shape      = function(cr, width, height)
		                       gears.shape.rectangle(cr, 48, 0)
		                       cr:stroke()       
	                               end,
                    
                            widget     = wibox.container.background,
                       }
                
         },
                  {
              layout = wibox.container.margin(nil,0,0,7,0),
           
                   wibox.widget {
                       {
                            left   = 1,
                            top    = 0,
                            bottom = 0,
                            right  = 0,

                            widget = wibox.container.margin,
                       },
                            bg         = "#ff0000",         
                            shape      = function(cr, width, height)
		                       gears.shape.rectangle(cr, 48, 16)
		                       cr:stroke()       
	                               end,
                    
                            widget     = wibox.container.background,
                       }
                
         },
        
    },
}

end)

-------------LEFT TITLEBAR ----------------

-- Add a titlebar if titlebars_enabled is set to true in the rules.
client.connect_signal("request::titlebars", function(c)
    -- buttons for the titlebar      
local left_titlebar = awful.titlebar(c, {
    
    size      = 1,
    bg_normal = "#7898fa",
    bg_focus  = "#7898fa",
    fg_normal = "#7898fa",
    fg_focus  = "#7898fa",
    position = 'left',
    -- resize_allowed = true,
    --bgimage = theme.titlebar_line,
    
})
-- buttons for the titlebar
local buttons = gears.table.join(
    awful.button({ }, 1, function()
        client.focus = c
        c:raise()
        awful.mouse.client.move(c)
    end),
    awful.button({ }, 3, function()
        client.focus = c
        c:raise()
        awful.mouse.client.resize(c)

    end)
)

local w = awful.titlebar.widget.titlewidget(c),

left_titlebar : setup {

layout = wibox.layout.fixed.vertical,

    { -- Left
      
      layout  = wibox.layout.fixed.vertical,
 
        {
              layout = wibox.container.margin(nil,0,0,0,0),
           
 
                
         },

  
    },

}

end)

-------------BOTTOM TITLEBAR  ----------------

-- Add a titlebar if titlebars_enabled is set to true in the rules.
client.connect_signal("request::titlebars", function(c)
    -- buttons for the titlebar      
local bottom_titlebar = awful.titlebar(c, {
    
    size      = 1,
    bg_normal = "#7898fa",
    bg_focus  = "#7898fa",
    fg_normal = "#7898fa",
    fg_focus  = "#7898fa",
    position = 'bottom',
    -- resize_allowed = true,
    --bgimage = theme.titlebar_line,
    
})
-- buttons for the titlebar
local buttons = gears.table.join(
    awful.button({ }, 1, function()
        client.focus = c
        c:raise()
        awful.mouse.client.move(c)
    end),
    awful.button({ }, 3, function()
        client.focus = c
        c:raise()
        awful.mouse.client.resize(c)

    end)
)

local w = awful.titlebar.widget.titlewidget(c),

bottom_titlebar : setup {

layout = wibox.layout.fixed.horizontal,

    { -- Left
      
      layout  = wibox.layout.fixed.horizontal,
 
        {
              layout = wibox.container.margin(nil,0,0,0,0),
           
                
         },

  
    },

}

end)

-------------RIGHT TITLEBAR  ----------------

-- Add a titlebar if titlebars_enabled is set to true in the rules.
client.connect_signal("request::titlebars", function(c)
    -- buttons for the titlebar      
local right_titlebar = awful.titlebar(c, {
    
    size      = 1,
    bg_normal = "#7898fa",
    bg_focus  = "#7898fa",
    fg_normal = "#7898fa",
    fg_focus  = "#7898fa",
    position = 'right',
    -- resize_allowed = true,
    --bgimage = theme.titlebar_line,
    
})
-- buttons for the titlebar
local buttons = gears.table.join(
    awful.button({ }, 1, function()
        client.focus = c
        c:raise()
        awful.mouse.client.move(c)
    end),
    awful.button({ }, 3, function()
        client.focus = c
        c:raise()
        awful.mouse.client.resize(c)

    end)
)

local w = awful.titlebar.widget.titlewidget(c),

right_titlebar : setup {

layout = wibox.layout.fixed.horizontal,

    { -- Left
      
      layout  = wibox.layout.fixed.horizontal,
 
        {
              layout = wibox.container.margin(nil,0,0,0,0),
           
                
         },

  
    },

}

end)













return theme
